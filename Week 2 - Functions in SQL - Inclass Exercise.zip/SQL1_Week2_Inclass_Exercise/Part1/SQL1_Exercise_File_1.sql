-- --------------------------------------------------------
# Datasets Used: cricket_1.csv, cricket_2.csv
-- cricket_1 is the table for cricket test match 1.
-- cricket_2 is the table for cricket test match 2.
-- --------------------------------------------------------

# Q1. Find all the unique players in both cricket 1 and 2 tables
 
# Q2. Write a query to extract the player details player_id, runs and player_name from the table “cricket_1” who
#  scored runs more than 50

# Q3. Write a query to extract all the columns from cricket_1 where player_name starts with ‘y’ and ends with ‘v’.
 
-- --------------------------------------------------------
# Dataset Used: cric_combined.csv 
-- --------------------------------------------------------

# Q5. Write a MySQL query to add a column PC_Ratio to the table that contains the divsion ratio 
# of popularity to charisma .(Hint :- Popularity divide by Charisma)

# Q6. Write a MySQL query to find the top 5 players having the highest popularity to charisma ratio.

# Q8. Extract Player_Id  and PC_Ratio where the PC_Ratio is between 0.12 and 0.25.

-- --------------------------------------------------------
# Dataset Used: new_cricket.csv
-- --------------------------------------------------------
# Q10. Write a MySQL query to display all the NULL values  in the column Charisma imputed with 0.

-- --------------------------------------------------------
# Dataset Used: churn1.csv 
-- --------------------------------------------------------
# Q18. Write a query to extract the customerID, InternetConnection and gender 
# from the table “churn1” where the value of the column “InternetConnection” has ‘i’ 
# at the second position.

# Q19. Find the records where the tenure is 6x, where x is any number.

# Q20. Write a query to display the player names in capital letter and arrange in alphabatical order along with the charisma, display 0 for whom the charisma value is NULL.
